Config = {}

Config.togCommand = "togplate" -- Command to turn on / off Plate

Config.distance = 20.5 -- Can be seen from here.

Config.height = 1.5 -- High the text should be from the car.

Config.country = "" -- License plate prefix. Default = off (example: EU-)






		