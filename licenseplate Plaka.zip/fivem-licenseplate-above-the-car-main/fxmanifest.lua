fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Szili#2513'
description 'Cars show the license plate above.'
version '1.2 Legacy'

shared_script 'config.lua'

client_script 'client.lua'

